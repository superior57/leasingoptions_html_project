$('#btn_header_toggle').click(function() {
    // $('#top_nav_bar').toggleClass('d-block');
});